package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    Button fetchdata;
    TextView detail,temp;
    EditText ecity, ecountry;

    private final String url = "https://api.openweathermap.org/data/2.5/weather";
    private final String appid = "782d666e1138433a80da87c5005f18ac";
    DecimalFormat df = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ecity = findViewById(R.id.city);

        detail = findViewById(R.id.detail);
        temp=findViewById(R.id.temp);
        fetchdata = findViewById(R.id.getBtn);

        fetchdata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String city = ecity.getText().toString().trim();

                String tempUrl = url + "?q=" + city + "&appid=" + appid;

                if (city.equals("")) {
                    detail.setText("City Field can not be empty!");
                }





                    StringRequest strReq = new StringRequest(Request.Method.POST, tempUrl, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("response", response);

                            String output = "";
                            try {
                                JSONObject jsonResponse = new JSONObject(response);
                                JSONArray array = jsonResponse.getJSONArray("weather");
                                JSONObject jsonObjWeather = array.getJSONObject(0);
                                String cityName = jsonResponse.getString("name");

                                JSONObject jsonObjectMain = jsonResponse.getJSONObject("main");
                                double temperature = jsonObjectMain.getDouble("temp") - 273.15;


                                JSONObject jsonObjectSys = jsonResponse.getJSONObject("sys");
                                String countryName = jsonObjectSys.getString("country");

                               /* output += "Current weather of" + cityName + "(" + countryName + ")"
                                        + "\nTemperature:" + df.format(temperature) + "ALT+0176"; */

                                detail.setText(cityName+"("+ countryName +")");
                                temp.setText((temperature) + " \u2103");


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(MainActivity.this, error.toString().trim(), Toast.LENGTH_SHORT).show();
                        }
                    });

                    RequestQueue reqQueue = Volley.newRequestQueue(getApplicationContext());
                    reqQueue.add(strReq);


            }
        });

    }
}
